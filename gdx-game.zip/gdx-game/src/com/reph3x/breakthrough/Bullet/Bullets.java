package com.reph3x.breakthrough.Bullet;

public enum Bullets
{
	BULLET,
	TARGETED,
	DOT,
	SLOW,
	EXPLOSION,
	LASER,
	BOOMERANG,
	ORBIT,
	EFFECTPOOL,
	WARP,
	HOMING,
	SPLIT;
}
